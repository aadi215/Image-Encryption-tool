
# Image Encryption Tool

This is a simple image encryption tool using pixel manipulation. It allows you to encrypt and decrypt images by applying mathematical operations to pixel values.

## Features
- Encrypt images with a default key.
- Decrypt encrypted images back to their original form.

## Requirements
Install the required Python libraries:
```
pip install pillow numpy
```

## Usage
1. Place your input image in the project directory.
2. Run the script:
   ```
   python image_encryption.py
   ```
3. Encrypted and decrypted images will be saved in the same directory.

## Example
- `sample_image.jpg` is encrypted to `encrypted_image.png`.
- `encrypted_image.png` is decrypted back to `decrypted_image.jpg`.

## Note
This tool uses a default encryption key of `50`. You can modify it in the script as needed.
